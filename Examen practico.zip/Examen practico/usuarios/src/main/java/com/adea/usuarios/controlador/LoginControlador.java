package com.adea.usuarios.controlador;

import com.adea.usuarios.modelo.Usuario;
import com.adea.usuarios.servicio.UsuarioServicio;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import lombok.Data;
import org.primefaces.PrimeFaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.LocalDate;

/**Autor Ing Elson Castillo
 * Clase de controller del login
 */


@Data
@SessionScoped
@Component
public class LoginControlador {

    @Autowired
    UsuarioServicio usuarioServicio;

    private String usuario;
    private String password;
    private LocalDate fechaLocal;


    public String validarLogin() throws IOException {
        //Obtiene la fecha vigencia de la BD
        LocalDate fechaVigencia = usuarioServicio.obtenerFechaVigenciaPorLogin(usuario);
       //Compara la fecha vigencia de la BD con la fecha actual para validar el Login
        if (fechaVigencia != null && fechaVigencia.isAfter(fechaLocal = LocalDate.now())) {
        //Si pasa hace la validacion del login con usuario y contraseña
            Usuario usuarioValidado = usuarioServicio.validarUsuario(usuario, password);
            if (usuarioValidado != null) {
                // Login exitoso, redirigir a página de bienvenida
                FacesContext.getCurrentInstance().getExternalContext().redirect("index.xhtml");
                return null;
            } else {
                // Mostrar mensaje de error usuario y contraseña incorrectos
                FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "¡Error!", "Usuario o contraseña incorrectos");
                PrimeFaces.current().dialog().showMessageDynamic(message);
                return null; // Permanece en la página de login
            }
        }else{
            // Mostrar mensaje de error fecha vegencia caduco
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "¡Error!", "No puede iniciar sesion la fecha vigencia caduco");
            PrimeFaces.current().dialog().showMessageDynamic(message);
            return null;
        }

    }

    // Getters y Setters para de los atributos generados de manera automatica
}
